package com.example.dq.ui;

import com.example.dq.ui.entity.ConnectionRequest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConnectionRepository extends JpaRepository<ConnectionRequest,Long> {

}
