package com.example.dq.ui.entity;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@Service
public class DBconnectionService {

    @Value("${spring.datasource.url}")
    public String dbConnectionUrl;

    @Value("${spring.datasource.username}")
    public String dbConnectionUserName;

    @Value("${spring.datasource.password}")
    public String dbConnectionPassword;


    public boolean testConnection(ConnectionRequest connectionRequest) {
        String url =
                "jdbc:postgresql://" +
                        connectionRequest.getHostname() + ":" +
                        connectionRequest.getPort() + "/" + connectionRequest.getDbName();
        return dbConnectionUrl.equals(url)
                && dbConnectionUserName.equals(connectionRequest.getUsername()) &&
                dbConnectionPassword.equals(connectionRequest.getPassword());
    }
}

       //import java.sql.Connection;
        //import java.sql.DriverManager;
        //import java.sql.SQLException;

        //import org.springframework.beans.factory.annotation.Value;
        //import org.springframework.stereotype.Component;

//@Component
//public class DatabaseConnectionValidator {

    //@Value("${spring.datasource.url}")
    //private String dbUrl;

   // @Value("${spring.datasource.username}")
  //  private String dbUsername;

 //   @Value("${spring.datasource.password}")
//    private String dbPassword;

   // public boolean validateConnection() {
        //try {
            // Load the PostgreSQL JDBC driver
            //Class.forName("org.postgresql.Driver");

            // Attempt to establish a connection
            //try (Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword)) {
                // If connection is successful, return true
             //   return true;
            //} catch (SQLException e) {
            //    // Connection failed, log the error and return false
           //     System.err.println("Connection failed: " + e.getMessage());
          //      return false;
         //   }
        //} catch (ClassNotFoundException e) {
            // JDBC driver not found, log the error and return false
       //     System.err.println("PostgreSQL JDBC Driver not found");
      //      e.printStackTrace();
     //       return false;
   //     }
  //  }
//}

